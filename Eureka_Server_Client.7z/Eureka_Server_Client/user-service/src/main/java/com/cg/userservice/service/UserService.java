package com.cg.userservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.userservice.VO.Department;
import com.cg.userservice.VO.ResponseTemplateVO;
import com.cg.userservice.entity.User;
import com.cg.userservice.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
    private RestTemplate restTemplate;
	
	public  User saveUser(User user) {
		log.info("inside user save method of sevice");
		log.info("I am save user method");
		return userRepository.save(user);
	}

	public ResponseTemplateVO getUserWithDepartment(Long userId) {
		log.info("inside user getUserWithDepartment method of sevice");
		
		ResponseTemplateVO vo = new ResponseTemplateVO();
		User user = userRepository.findByUserId(userId);
		
		//not use @LoadBalancer-->annotation in restTemplate object(if use ,shows error)
		//Department department =restTemplate.getForObject("http://localhost:9001/departments/"+user.getDepartmentId(), Department.class);
		
		//use @LoadBalancer-->annotation in restTemplate object
		Department department =restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/"+user.getDepartmentId(), Department.class);
		vo.setUser(user);
		vo.setDepartment(department);
		return vo;
	}

}
