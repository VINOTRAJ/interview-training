package com.cg.department.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.department.entity.Department;
//@EnableJpaRepositories
@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

	//Department findDepartmentById(Long departmentId);
	
	Department findByDepartmentId(Long departmentId);

}
