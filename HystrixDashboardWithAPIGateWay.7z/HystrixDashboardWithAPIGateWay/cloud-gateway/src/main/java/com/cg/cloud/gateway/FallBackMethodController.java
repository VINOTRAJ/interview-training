package com.cg.cloud.gateway;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallBackMethodController {

	@GetMapping("/organizationServiceFallBack")
	public String organizationServiceFallBackMethod() {
		return "Organization Service is taking longer than expected..Please try again Later";
	}
	
	@GetMapping("/employeeServiceFallBack")
	public String employeeServiceFallBackMethod() {
		return "Employee Service is taking longer than expected..Please try again Later";
	}
}
