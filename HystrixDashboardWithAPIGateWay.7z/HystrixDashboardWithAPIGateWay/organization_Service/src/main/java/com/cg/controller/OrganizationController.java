package com.cg.controller;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.VO.ResponseTemplateVO;
//import com.cg.VO.ResponseTemplateVO;
import com.cg.entity.Organization;
import com.cg.service.OrganizationService;





@RestController
@RequestMapping("/organizations")
public class OrganizationController {

    @Autowired
    private OrganizationService organizationService;

    @PostMapping("/")
    public Organization saveOrganization(@RequestBody Organization organization) {
        
        return organizationService.saveOrganization(organization);
    }
  
    @GetMapping("/{orgId}")
	public ResponseTemplateVO getOrgWithEmployee(@PathVariable int orgId) {
		return organizationService.getOrgWithEmployee(orgId);
	}
    
  
}
