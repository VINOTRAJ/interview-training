package com.cg.service;







import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.VO.Employee;
import com.cg.VO.ResponseTemplateVO;


import com.cg.entity.Organization;
import com.cg.repository.OrganizationRepository;


@Service
public class OrganizationService {

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private RestTemplate restTemplate;

    public Organization saveOrganization(Organization organization) {
       
        return organizationRepository.save(organization);
    }

   
    

    public ResponseTemplateVO getOrgWithEmployee(int orgId) {
		ResponseTemplateVO vo = new ResponseTemplateVO();
		Organization organization = organizationRepository.findByOrganizationId(orgId);
		Employee employee =restTemplate.getForObject("http://EMPLOYEE-SERVICE/employees/"+organization.getEmployeeId(), Employee.class);
		vo.setOrganization(organization);
		vo.setEmployee(employee);
		return vo;
	}

}
